document.addEventListener("DOMContentLoaded", () => {
  const STORAGE_KEY = "expenses";

  const SALARIES_PER_MONTH = 1;

  const PERIOD_LABELS = {
    daily: "Ежедневные",
    weekly: "Еженедельные",
    monthly: "Ежемесячные",
    yearly: "Ежегодные"
  };

  const PERIOD_ORDER = ["daily", "weekly", "monthly", "yearly"];

  const PERIOD_MULTIPLIER = {
    daily: 365 / 12,
    weekly: 52 / 12,
    monthly: 1,
    yearly: 1 / 12
  };

  const periodSelect    = document.getElementById("period");
  const titleInput      = document.getElementById("title");
  const amountInput     = document.getElementById("amount");
  const saveButton      = document.getElementById("save");

  const listEl          = document.getElementById("list");
  const mainValueEl     = document.getElementById("mainValue");
  const totalYearValueEl = document.getElementById("totalYearValue");

  const loader          = document.getElementById("loader");

  const confirmModal    = document.getElementById("confirmModal");
  const cancelDelete    = document.getElementById("cancelDelete");
  const confirmDelete   = document.getElementById("confirmDelete");

  const editModal       = document.getElementById("editModal");
  const editPeriod      = document.getElementById("editPeriod");
  const editTitle       = document.getElementById("editTitle");
  const editAmount      = document.getElementById("editAmount");
  const cancelEdit      = document.getElementById("cancelEdit");
  const confirmEdit     = document.getElementById("confirmEdit");

  const exportJsonBtn   = document.getElementById("exportJson");
  const importJsonBtn   = document.getElementById("importJson");
  const importFileInput = document.getElementById("importFile");

  let deleteId = null;
  let editId   = null;

  function formatNumber(num) {
    return Math.round(num).toLocaleString('ru-RU');
  }

  // ────────────────────────────────────────────────
  // Двойное хранение: sync + local fallback
  // ────────────────────────────────────────────────

  async function getExpenses() {
    try {
      // Сначала пробуем sync
      const syncData = await chrome.storage.sync.get(STORAGE_KEY);
      if (syncData[STORAGE_KEY] && Array.isArray(syncData[STORAGE_KEY])) {
        return syncData[STORAGE_KEY];
      }
    } catch (err) {
      console.warn("sync get failed, fallback to local", err);
    }

    // Если sync не сработал или пусто — берём local
    const localData = await chrome.storage.local.get(STORAGE_KEY);
    return localData[STORAGE_KEY] || [];
  }

  async function saveExpenses(items) {
    try {
      // Пишем в sync (если получится)
      await chrome.storage.sync.set({ [STORAGE_KEY]: items });
    } catch (err) {
      console.warn("sync save failed", err);
    }

    // Всегда пишем в local (надёжно)
    await chrome.storage.local.set({ [STORAGE_KEY]: items });
  }

  // ────────────────────────────────────────────────
  // Остальной код без изменений
  // ────────────────────────────────────────────────

  saveButton.onclick = async () => {
    const title = titleInput.value.trim();
    const amount = Number(amountInput.value);
    const period = periodSelect.value;

    if (!title || amount <= 0 || isNaN(amount)) {
      alert("Заполните описание и сумму > 0");
      return;
    }

    const items = await getExpenses();
    items.push({ id: crypto.randomUUID(), title, amount, period });
    await saveExpenses(items);

    titleInput.value = "";
    amountInput.value = "";
    render();
  };

  async function render() {
    loader.classList.remove("hidden");

    try {
      const items = await getExpenses();
      listEl.innerHTML = "";

      let monthlyTotal = 0;
      const grouped = {};
      const periodSums = { daily: 0, weekly: 0, monthly: 0, yearly: 0 };

      items.forEach(item => {
        const coef = PERIOD_MULTIPLIER[item.period] || 1;
        monthlyTotal += item.amount * coef;

        grouped[item.period] = grouped[item.period] || [];
        grouped[item.period].push(item);

        if (periodSums[item.period] !== undefined) {
          periodSums[item.period] += item.amount;
        }
      });

      Object.values(grouped).forEach(group => {
        group.sort((a, b) => b.amount - a.amount);
      });

      const needToSave = monthlyTotal / SALARIES_PER_MONTH;
      const totalPerYear = monthlyTotal * 12;

      mainValueEl.textContent     = formatNumber(needToSave) + " ₽";
      totalYearValueEl.textContent = formatNumber(totalPerYear) + " ₽";

      PERIOD_ORDER.forEach(period => {
        if (!grouped[period] || grouped[period].length === 0) return;

        const sum = periodSums[period];
        const titleLi = document.createElement("li");
        titleLi.className = "group-title";
        titleLi.innerHTML = `
          ${PERIOD_LABELS[period]}
          <strong>${formatNumber(sum)} ₽</strong>
        `;
        listEl.appendChild(titleLi);

        grouped[period].forEach(item => {
          const li = document.createElement("li");
          li.className = "item";
          li.innerHTML = `
            <span>${item.title} — ${formatNumber(item.amount)} ₽</span>
            <button class="delete-btn">✕</button>
          `;

          li.addEventListener("click", e => {
            if (e.target.classList.contains("delete-btn")) return;
            editId = item.id;
            editPeriod.value = item.period;
            editTitle.value = item.title;
            editAmount.value = item.amount;
            editModal.classList.remove("hidden");
          });

          li.querySelector(".delete-btn").onclick = e => {
            e.stopPropagation();
            deleteId = item.id;
            confirmModal.classList.remove("hidden");
          };

          listEl.appendChild(li);
        });
      });
    } catch (err) {
      console.error("Ошибка рендера:", err);
    } finally {
      loader.classList.add("hidden");
    }
  }

  cancelDelete.onclick = () => {
    deleteId = null;
    confirmModal.classList.add("hidden");
  };

  confirmDelete.onclick = async () => {
    if (!deleteId) return;
    const items = await getExpenses();
    await saveExpenses(items.filter(i => i.id !== deleteId));
    deleteId = null;
    confirmModal.classList.add("hidden");
    render();
  };

  cancelEdit.onclick = () => {
    editId = null;
    editModal.classList.add("hidden");
  };

  confirmEdit.onclick = async () => {
    if (!editId) return;

    const title = editTitle.value.trim();
    const amount = Number(editAmount.value);
    const period = editPeriod.value;

    if (!title || amount <= 0 || isNaN(amount)) {
      alert("Заполните описание и сумму > 0");
      return;
    }

    const items = await getExpenses();
    const item = items.find(i => i.id === editId);
    if (item) {
      item.title = title;
      item.amount = amount;
      item.period = period;
      await saveExpenses(items);
    }

    editId = null;
    editModal.classList.add("hidden");
    render();
  };

  // Экспорт JSON
  exportJsonBtn.onclick = async () => {
    const items = await getExpenses();
    const json = JSON.stringify(items, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "expenses.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  // Импорт JSON
  importJsonBtn.onclick = () => {
    importFileInput.click();
  };

  importFileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!confirm("Импорт перезапишет все текущие расходы. Продолжить?")) {
      e.target.value = "";
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const items = JSON.parse(event.target.result);
        if (!Array.isArray(items)) throw new Error("Неверный формат");
        // Простая валидация
        items.forEach(item => {
          if (!item.id || !item.title || isNaN(item.amount) || !PERIOD_MULTIPLIER[item.period]) {
            throw new Error("Неверные данные в файле");
          }
        });
        await saveExpenses(items);
        render();
        alert("Импорт успешен");
      } catch (err) {
        alert("Ошибка импорта: " + err.message);
      } finally {
        e.target.value = "";
      }
    };
    reader.readAsText(file);
  };

  render();
});